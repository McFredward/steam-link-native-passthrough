Steam Link Native Passthrough installer 0.3.15 - reviewed setup
PC patch 0.3.11; Frame patch 0.3.5.
Logging default: Debug (dev).

Run patch-steam-link.cmd on Windows. Confirmed setup prepares Frame files while its interface stays running, then coordinates and monitors the required restart.
The Linux PC sender is not included. Native-derived shaders are generated locally, never shipped.
Setup closes only verified PC SteamVR processes and leaves PC SteamVR closed. PC-only updates preserve Frame files, settings and services without a Frame restart.
When Frame changes are needed, setup restarts/checks its interface and asks you to confirm the picture.
A failed start restores the exact original operation checkpoint and restarts the original Frame interface. Incomplete recovery offers Retry.
Use the current guided paired setup. There is no Frame-only atlas fallback.
