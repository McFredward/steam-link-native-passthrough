Steam Link Native Passthrough installer 0.3.16-roomscan.11 - reviewed setup
PC patch 0.3.12-roomscan.8; Frame patch 0.3.9-roomscan.11.
Logging default: Debug (dev).

Run patch-steam-link.cmd on Windows. Confirmed setup prepares Frame files while its interface stays running, then coordinates and monitors the required restart.
The Linux PC sender is not included. Native-derived shaders are generated locally, never shipped.
Setup closes only verified PC SteamVR processes and leaves PC SteamVR closed. PC-only updates preserve Frame files, settings and services without a Frame restart.
When Frame changes are needed, setup restarts/checks its interface and asks you to confirm the picture.
A failed start restores the exact original operation checkpoint and restarts the original Frame interface. Incomplete recovery offers Retry.
Use the current guided paired setup. There is no Frame-only atlas fallback.

EXPERIMENTAL ARCTURUS ROOM SETUP
After the confirmed paired installation, open the Frame-local SteamVR dashboard and choose Room Setup.
Use the top-right X to return to the SteamVR menu and stop capture. The dashboard stays open and Room Setup remains available to open again.
Choose Scan a new room, then Start scan. Startup alone never acquires camera images.
Room scanning is required in this feature build. The paired installer activates and verifies the camera reader, prepares the PC runtime and waits for GPU warmup and a live Frame connection. No separate Enable action is required. Failure offers Try again without undoing the healthy native installation.
Reboot leaves the camera reader inactive; reopening the verified current paired installer activates it again. PC reconstruction files are under %LOCALAPPDATA%/steam-link-native-passthrough/room-pc-runtime.
Keep native colour passthrough visible. Start/Resume opens the native room view; close any running VR game first. The SteamVR dashboard entry stays available.
Wait for PC reconstruction is running, then keep the Windows installer open throughout the scan. It prepares private CUDA/ONNX dependencies and C-Fast-FoundationStereo (about 1.7 GB download, 5 GB free disk and 3 GB free NVIDIA VRAM). No system GPU drivers or Python packages are installed.
The PC continuously refines geometric Gaussian surface splats. Turquoise reveals new coverage; amber needs more viewpoints. Unknown areas stay open. Continue extracts measured polygons for editing and saving. NVIDIA/headset speed and accuracy require the combined test.
If the camera source cannot be verified, scanning stays unavailable. This package contains no simulated room fallback.
Mark three rectangle corners with the trigger, using reliable scan surfaces or Measure at controller. Confirm the preview, then review and save.
Tables, walls, doors/windows and furniture support manual entry. Automatic object recognition and game/Venture scene adapters are not included yet.
Saved rooms require explicit realignment after restarting. User rooms survive update, Undo and uninstall.
