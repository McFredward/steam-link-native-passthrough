Steam Link Native Passthrough installer 0.3.16-roomscan.2 - reviewed setup
PC patch 0.3.11; Frame patch 0.3.6-roomscan.2.
Logging default: Debug (dev).

Run patch-steam-link.cmd on Windows. Confirmed setup prepares Frame files while its interface stays running, then coordinates and monitors the required restart.
The Linux PC sender is not included. Native-derived shaders are generated locally, never shipped.
Setup closes only verified PC SteamVR processes and leaves PC SteamVR closed. PC-only updates preserve Frame files, settings and services without a Frame restart.
When Frame changes are needed, setup restarts/checks its interface and asks you to confirm the picture.
A failed start restores the exact original operation checkpoint and restarts the original Frame interface. Incomplete recovery offers Retry.
Use the current guided paired setup. There is no Frame-only atlas fallback.

EXPERIMENTAL ARCTURUS ROOM SETUP
After the confirmed paired installation, open the Frame-local SteamVR dashboard and choose Raumeinrichtung.
Choose Neuen Raum scannen, then Scan starten. Startup alone never acquires camera images.
Use visible native colour passthrough. Actual public Arcturus stereo access, projection alignment and active-game coexistence are not hardware verified.
If the camera source cannot be verified, scanning stays unavailable. This package contains no simulated room fallback.
Mark three rectangle corners with the trigger, using reliable scan surfaces or Am Controller messen. Confirm the preview, then review and save.
Tables, walls, doors/windows and furniture support manual entry. Automatic object recognition and game/Venture scene adapters are not included yet.
Saved rooms require explicit realignment after restarting. User rooms survive update, Undo and uninstall.
