Venture source-admission diagnostic candidate, 2026-11-08
Installer 0.3.16-venture.1; PC patch 0.3.12-venture.1; Frame patch 0.3.5.
Experimental diagnostics, not a confirmed MR fix or a headset-verified build.
Uses the unchanged stable 0.3.15 installer and Frame payload.
Only the PC provider has changed; admission and pixel processing are unchanged.
Logging stays Important; RGB debug telemetry stays disabled.
For a current intact Frame 0.3.5 installation, setup offers a PC-only update.
Do not confirm a paired Frame install/repair for this diagnostic capture.
Run patch-steam-link.cmd on Windows; after the PC-only update start SteamVR
and the Venture diagnostic build with MR enabled. Reproduce for 20 seconds,
then collect the normal Venture and PC SteamVR logs.
